</div> <!-- #wrapper -->

<footer>
    <div id="footer-contents">
        <a href="http://siggrapharts.ning.com/"><img height="77" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/dac_logo.png"></a>
        <a href="https://www.siggraph.org/"><img height="77" src="<?php echo esc_url( get_template_directory_uri() ); ?>/img/sig_logo.png"></a>
    </div>
</footer>

<?php wp_footer(); ?>
</body>
</html>